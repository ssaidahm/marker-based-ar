Saidahmed Saidahmed [g-number: 01058254]
Project 3

Image run: python3 augmented_reality_with_aruco.py --image=test.jpg
Video run: python3 augmented_reality_with_aruco.py --video=project.mp4


Requirements Implemented:
- Part 2: Your Own Markers
- Part 3: Live Editing

Requirements Not Implemented:
- Part 4: Swapping AR Objects
- Part 5: Particle Animation

Extra Credits:
- N/A

Other Notes:
- Was given a penalty-free late submission. Unfortunately, I have a wedding to attend to in Fredrickburg, will try my best to work on it and resubmit the project. Submitting what I have done for now. 